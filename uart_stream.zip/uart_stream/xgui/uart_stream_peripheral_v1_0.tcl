# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  ipgui::add_param $IPINST -name "AXI_ADDR_W" -parent ${Page_0}
  ipgui::add_param $IPINST -name "AXI_DATA_W" -parent ${Page_0}
  ipgui::add_param $IPINST -name "DEFAULT_BAUD" -parent ${Page_0}
  ipgui::add_param $IPINST -name "FIFO_DEPTH" -parent ${Page_0}
  ipgui::add_param $IPINST -name "FIFO_PTR_W" -parent ${Page_0}
  ipgui::add_param $IPINST -name "M_AXI_ADDR_W" -parent ${Page_0}
  ipgui::add_param $IPINST -name "SYS_CLK_HZ" -parent ${Page_0}


}

proc update_PARAM_VALUE.AXI_ADDR_W { PARAM_VALUE.AXI_ADDR_W } {
	# Procedure called to update AXI_ADDR_W when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.AXI_ADDR_W { PARAM_VALUE.AXI_ADDR_W } {
	# Procedure called to validate AXI_ADDR_W
	return true
}

proc update_PARAM_VALUE.AXI_DATA_W { PARAM_VALUE.AXI_DATA_W } {
	# Procedure called to update AXI_DATA_W when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.AXI_DATA_W { PARAM_VALUE.AXI_DATA_W } {
	# Procedure called to validate AXI_DATA_W
	return true
}

proc update_PARAM_VALUE.DEFAULT_BAUD { PARAM_VALUE.DEFAULT_BAUD } {
	# Procedure called to update DEFAULT_BAUD when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.DEFAULT_BAUD { PARAM_VALUE.DEFAULT_BAUD } {
	# Procedure called to validate DEFAULT_BAUD
	return true
}

proc update_PARAM_VALUE.FIFO_DEPTH { PARAM_VALUE.FIFO_DEPTH } {
	# Procedure called to update FIFO_DEPTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.FIFO_DEPTH { PARAM_VALUE.FIFO_DEPTH } {
	# Procedure called to validate FIFO_DEPTH
	return true
}

proc update_PARAM_VALUE.FIFO_PTR_W { PARAM_VALUE.FIFO_PTR_W } {
	# Procedure called to update FIFO_PTR_W when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.FIFO_PTR_W { PARAM_VALUE.FIFO_PTR_W } {
	# Procedure called to validate FIFO_PTR_W
	return true
}

proc update_PARAM_VALUE.M_AXI_ADDR_W { PARAM_VALUE.M_AXI_ADDR_W } {
	# Procedure called to update M_AXI_ADDR_W when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.M_AXI_ADDR_W { PARAM_VALUE.M_AXI_ADDR_W } {
	# Procedure called to validate M_AXI_ADDR_W
	return true
}

proc update_PARAM_VALUE.SYS_CLK_HZ { PARAM_VALUE.SYS_CLK_HZ } {
	# Procedure called to update SYS_CLK_HZ when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.SYS_CLK_HZ { PARAM_VALUE.SYS_CLK_HZ } {
	# Procedure called to validate SYS_CLK_HZ
	return true
}


proc update_MODELPARAM_VALUE.SYS_CLK_HZ { MODELPARAM_VALUE.SYS_CLK_HZ PARAM_VALUE.SYS_CLK_HZ } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.SYS_CLK_HZ}] ${MODELPARAM_VALUE.SYS_CLK_HZ}
}

proc update_MODELPARAM_VALUE.DEFAULT_BAUD { MODELPARAM_VALUE.DEFAULT_BAUD PARAM_VALUE.DEFAULT_BAUD } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.DEFAULT_BAUD}] ${MODELPARAM_VALUE.DEFAULT_BAUD}
}

proc update_MODELPARAM_VALUE.AXI_ADDR_W { MODELPARAM_VALUE.AXI_ADDR_W PARAM_VALUE.AXI_ADDR_W } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.AXI_ADDR_W}] ${MODELPARAM_VALUE.AXI_ADDR_W}
}

proc update_MODELPARAM_VALUE.AXI_DATA_W { MODELPARAM_VALUE.AXI_DATA_W PARAM_VALUE.AXI_DATA_W } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.AXI_DATA_W}] ${MODELPARAM_VALUE.AXI_DATA_W}
}

proc update_MODELPARAM_VALUE.M_AXI_ADDR_W { MODELPARAM_VALUE.M_AXI_ADDR_W PARAM_VALUE.M_AXI_ADDR_W } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.M_AXI_ADDR_W}] ${MODELPARAM_VALUE.M_AXI_ADDR_W}
}

proc update_MODELPARAM_VALUE.FIFO_DEPTH { MODELPARAM_VALUE.FIFO_DEPTH PARAM_VALUE.FIFO_DEPTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.FIFO_DEPTH}] ${MODELPARAM_VALUE.FIFO_DEPTH}
}

proc update_MODELPARAM_VALUE.FIFO_PTR_W { MODELPARAM_VALUE.FIFO_PTR_W PARAM_VALUE.FIFO_PTR_W } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.FIFO_PTR_W}] ${MODELPARAM_VALUE.FIFO_PTR_W}
}

